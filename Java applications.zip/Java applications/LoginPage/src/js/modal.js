$("#myModal").modal()

$("#editModal").modal()

$("#editDetails").modal()
